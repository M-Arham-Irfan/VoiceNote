package com.example.voicenot;

public class WeatherAlertReceiver {
}
