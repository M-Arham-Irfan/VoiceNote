package com.example.voicenot;

public class FusedLocationProviderClient {
}
